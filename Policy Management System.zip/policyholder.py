{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "c3671a5b-f633-4967-a6f6-6156e408d71b",
   "metadata": {},
   "outputs": [],
   "source": [
    "class Policyholder:\n",
    "    def __init__(self, name, id_number, status=\"Active\"):\n",
    "        self.name = name\n",
    "        self.id_number = id_number\n",
    "        self.status = status\n",
    "\n",
    "    def suspend(self):\n",
    "        self.status = \"Suspended\"\n",
    "        print(f\"Policyholder {self.name} has been suspended.\")\n",
    "\n",
    "    def reactivate(self):\n",
    "        self.status = \"Active\"\n",
    "        print(f\"Policyholder {self.name} has been reactivated.\")\n",
    "\n",
    "    def display_details(self):\n",
    "        return f\"Name: {self.name}, ID: {self.id_number}, Status: {self.status}\""
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
