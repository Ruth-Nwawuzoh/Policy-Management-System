{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "883f494f-d86b-46fa-8ab0-f003ea7205b6",
   "metadata": {},
   "outputs": [],
   "source": [
    "class Product:\n",
    "    def __init__(self, product_id, name, price, status=\"Available\"):\n",
    "        self.product_id = product_id\n",
    "        self.name = name\n",
    "        self.price = price\n",
    "        self.status = status\n",
    "\n",
    "    def update(self, name=None, price=None):\n",
    "        if name:\n",
    "            self.name = name\n",
    "        if price:\n",
    "            self.price = price\n",
    "        print(f\"Product {self.product_id} updated.\")\n",
    "\n",
    "    def suspend(self):\n",
    "        self.status = \"Suspended\"\n",
    "        print(f\"Product {self.name} has been suspended.\")\n",
    "\n",
    "    def display_details(self):\n",
    "        return f\"Product ID: {self.product_id}, Name: {self.name}, Price: {self.price}, Status: {self.status}\"\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
