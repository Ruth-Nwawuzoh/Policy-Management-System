{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "4f981613-746c-4f9e-9b5b-f4cf82754e44",
   "metadata": {},
   "outputs": [],
   "source": [
    "class Payment:\n",
    "    def __init__(self, payment_id, policyholder_id, amount, status=\"Pending\"):\n",
    "        self.payment_id = payment_id\n",
    "        self.policyholder_id = policyholder_id\n",
    "        self.amount = amount\n",
    "        self.status = status\n",
    "\n",
    "    def process_payment(self):\n",
    "        self.status = \"Completed\"\n",
    "        print(f\"Payment of {self.amount} for Policyholder ID {self.policyholder_id} processed.\")\n",
    "\n",
    "    def send_reminder(self):\n",
    "        if self.status == \"Pending\":\n",
    "            print(f\"Reminder: Payment of {self.amount} is due for Policyholder ID {self.policyholder_id}.\")\n",
    "\n",
    "    def apply_penalty(self, penalty_amount):\n",
    "        if self.status == \"Pending\":\n",
    "            self.amount += penalty_amount\n",
    "            print(f\"Penalty applied. New amount due: {self.amount}\")\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
